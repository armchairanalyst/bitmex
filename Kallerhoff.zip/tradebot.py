import os
import sys
import json
import time
from pathlib import Path
from BitmexWrapper import BitAPIWrapper




curdir = Path.cwd()

# region External Files
config = None
configfile = curdir / "config.json"


# endregion

# region External File Access

# Load the config data...

with configfile.open() as cf:
    config = json.load(cf)

# endregion

apikey = config["BITMEX"]["APIKEY"]
apisec = config["BITMEX"]["APISECRET"]

buypricefactor = float(config["BOT"]["BUYLIMITPERCENTAGE"])
buypricefactor = 1.0 - (buypricefactor/100.0)

sellpricefactor = float(config["BOT"]["SELLLIMITPERCENTAGE"])
sellpricefactor = 1.0 + (sellpricefactor/100.0)

quantity = int(config["BOT"]["QUANTITY"])

timedelay = int(config["BOT"]["DELAY_BETWEEN_ORDERS"])

currencylist = config["CURRENCY_LIST"]


wrapper = BitAPIWrapper(api_key=apikey, api_secret=apisec,isDemo=False)

def PlaceOrders():
    global wrapper, currencylist, buypricefactor, sellpricefactor, quantity, timedelay

    for currency in currencylist:
        presentprice = wrapper.GetPrice(sym=currency)
        buyprice = int(presentprice*buypricefactor)
        sellprice = int(presentprice*sellpricefactor)
        print("--------------------------------------------")
        print("Current Price of "+currency+" is "+ str(presentprice))
        print("--------------------------------------------")
        try:
            res = wrapper.PlaceBuyLimitOrder(sym=currency, price=buyprice, qty=quantity)
        except Exception as e:
            print("Error executing above trade ####> " + str(e))


        time.sleep(timedelay)

        try:
            res = wrapper.PlaceSellLimitOrder(sym=currency, price=sellprice, qty=quantity)
        except Exception as e:
            print("Error executing above trade ####> " + str(e))

        input("Press any key to continue....")


if __name__ == '__main__':
    PlaceOrders()



